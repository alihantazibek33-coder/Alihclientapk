package com.alihclient.bedrock;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingMenuService extends Service {
    WindowManager wm;
    WindowManager.LayoutParams params;
    TextView bubble;
    LinearLayout panel;
    boolean opened = false;
    int startX, startY;
    float touchX, touchY;

    GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(3, stroke); return d;
    }
    TextView item(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = 24; params.y = 260;

        bubble = item("N", 20, Color.WHITE, true);
        bubble.setBackground(shape(Color.rgb(24,119,170), 100, Color.rgb(99,229,255)));
        bubble.setElevation(12);
        bubble.setPadding(18,14,18,14);
        bubble.setOnTouchListener((v,e) -> {
            if (e.getAction()==MotionEvent.ACTION_DOWN) {
                startX=params.x; startY=params.y; touchX=e.getRawX(); touchY=e.getRawY(); return true;
            }
            if (e.getAction()==MotionEvent.ACTION_MOVE) {
                params.x=startX+(int)(e.getRawX()-touchX); params.y=startY+(int)(e.getRawY()-touchY);
                try { wm.updateViewLayout(bubble,params); } catch(Exception ignored) {}
                return true;
            }
            if (e.getAction()==MotionEvent.ACTION_UP) {
                if (Math.abs(e.getRawX()-touchX)<10 && Math.abs(e.getRawY()-touchY)<10) toggle();
                return true;
            }
            return false;
        });
        wm.addView(bubble,params);
    }
    void toggle() {
        if (opened) { if(panel!=null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; } opened=false; return; }
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(16,14,16,14);
        panel.setBackground(shape(Color.rgb(13,22,41),24,Color.rgb(99,229,255)));
        TextView title=item("NEON MENU",16,Color.rgb(99,229,255),true);
        panel.addView(title,new LinearLayout.LayoutParams(220,48));
        TextView launch=item("▶  Ашылған мәзірді жабу",14,Color.WHITE,false);
        panel.addView(launch,new LinearLayout.LayoutParams(220,46));
        launch.setOnClickListener(v -> toggle());
        TextView close=item("✕  Жабу",14,Color.LTGRAY,true);
        panel.addView(close,new LinearLayout.LayoutParams(220,42));
        close.setOnClickListener(v -> toggle());
        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        pp.gravity=Gravity.TOP|Gravity.START; pp.x=params.x; pp.y=params.y+70;
        wm.addView(panel,pp); opened=true;
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) { return START_STICKY; }
    @Override public void onDestroy() { if(bubble!=null) try{wm.removeView(bubble);}catch(Exception ignored){} if(panel!=null)try{wm.removeView(panel);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
