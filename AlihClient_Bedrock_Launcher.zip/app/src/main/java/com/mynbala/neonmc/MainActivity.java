package com.alihclient.bedrock;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    final int bg = Color.rgb(8,13,27), panel = Color.rgb(18,27,48), cyan = Color.rgb(99,229,255);
    TextView status;
    GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }
    TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(shape(Color.rgb(26,91,126), 26, cyan));
        return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,24);
        scroll.addView(root);

        root.addView(label("◆  AlihClient", 28, cyan, true));
        TextView sub = label("BEDROCK EDITION  •  MOBILE LAUNCHER", 11, Color.LTGRAY, true);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-2,-2); subp.topMargin=5; subp.bottomMargin=24;
        root.addView(sub, subp);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(1); hero.setPadding(20,24,20,22);
        hero.setBackground(shape(panel, 28, Color.rgb(40,105,145))); root.addView(hero);
        hero.addView(label("YOUR WORLD. YOUR RULES.", 12, cyan, true));
        TextView title = label("Minecraft Bedrock", 27, Color.WHITE, true);
        LinearLayout.LayoutParams tpar = new LinearLayout.LayoutParams(-1,-2); tpar.topMargin=10; hero.addView(title,tpar);
        TextView desc = label("Телефондағы Minecraft Bedrock-ты осы жерден аш.", 14, Color.LTGRAY, false);
        LinearLayout.LayoutParams dpar = new LinearLayout.LayoutParams(-1,-2); dpar.topMargin=8; dpar.bottomMargin=18; hero.addView(desc,dpar);

        Button launch = btn("▶   MINECRAFT-ТЫ ІСКЕ ҚОСУ");
        hero.addView(launch, new LinearLayout.LayoutParams(-1,58));
        launch.setOnClickListener(v -> launchMinecraft());

        addGap(root, 20);
        root.addView(label("НҰСҚА", 13, cyan, true));
        addGap(root, 8);
        LinearLayout versionCard = card(root);
        versionCard.addView(label("Орнатылған Bedrock нұсқасы", 16, Color.WHITE, true));
        versionCard.addView(label("Android жүйесі бірнеше Minecraft нұсқасын автоматты түрде таңдауға мүмкіндік бермейді. Бұл батырма құрылғыдағы орнатылған нұсқаны ашады.", 13, Color.LTGRAY, false));
        addGap(root, 18);
        root.addView(label("FLOATING MENU", 13, cyan, true));
        addGap(root, 8);
        LinearLayout floating = card(root);
        floating.addView(label("Экрандағы домалақ батырма", 16, Color.WHITE, true));
        floating.addView(label("Minecraft үстінде жылжытуға болатын шағын мәзір көрсетеді. Алдымен экран үстінен көрсетуге рұқсат бер.", 13, Color.LTGRAY, false));
        Button overlay = btn("◉   Домалақ мәзірді қосу");
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1,52); op.topMargin=14; floating.addView(overlay,op);
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, FloatingMenuService.class));
                Toast.makeText(this, "Домалақ мәзір қосылды", Toast.LENGTH_SHORT).show();
            }
        });

        addGap(root, 18);
        root.addView(label("Маңызды", 13, cyan, true));
        TextView note = label("Бұл — Bedrock-қа арналған лаунчер жобасы. APK бұл жерде дайын компиляцияланбаған; жобаны Android Studio/Android build ортасында жинау керек. Minecraft өзі бөлек орнатылған болуы тиіс.", 12, Color.LTGRAY, false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=7; root.addView(note,np);
        setContentView(scroll);
    }
    void addGap(LinearLayout l, int h) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1,h));
    }
    LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(1); c.setPadding(16,16,16,16);
        c.setBackground(shape(panel,22,Color.rgb(35,58,88)));
        parent.addView(c,new LinearLayout.LayoutParams(-1,-2)); return c;
    }
    void launchMinecraft() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
        if (i != null) startActivity(i);
        else new android.app.AlertDialog.Builder(this).setTitle("Minecraft табылмады")
            .setMessage("Minecraft Bedrock құрылғыға орнатылғанына көз жеткіз. Бұл лаунчер Minecraft-ты өзі жүктемейді.")
            .setPositiveButton("OK", null).show();
    }
}
